package simulator.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

import org.json.JSONArray;
import org.json.JSONObject;

public class TrafficSimulator implements Observable<TrafficSimObserver>{

	List<TrafficSimObserver> _observers;
    RoadMap _roadMap;
    Queue<Event> _events;
    int _time;

    public TrafficSimulator() {
    	_observers = new ArrayList<TrafficSimObserver>();
        _roadMap = new RoadMap();
        _events = new PriorityQueue<>();
        _time = 0;
    }

    
    public void reset() {
    	this._roadMap.clear();
    	this._events.clear();
    	this._time = 0; 
    	for (TrafficSimObserver o :_observers) {
    		o.onReset(_roadMap, _events, _time);
    	}  	
    }
    
    public void addEvent(Event e) throws IllegalArgumentException{ 
    	if(e.getTime() <= this._time) throw new IllegalArgumentException("Invalid Time");
    	this._events.add(e);
    	for (TrafficSimObserver o :_observers) {
    		o.onEventAdded(_roadMap, _events, e, _time);
    	}
    }
    
    public void advance() {
    	this._time++;
    	Iterator<Event> it = this._events.iterator();
    	boolean tiempoMenor = true;
    	List<Event> listaRemove = new ArrayList<Event>();
    	
    	while(_events.size()>0 && _events.peek().getTime() == this._time) {
    		_events.poll().execute(_roadMap);
    	}
    	advanceJunctions();
    	advanceRoads();
    	for (TrafficSimObserver o :_observers) {
    		o.onAdvance(_roadMap, _events, _time);
    	}
    }


	private void advanceJunctions() {
		// TODO Auto-generated method stub
		List<Junction> MapaJunctions = new ArrayList<Junction>();
		MapaJunctions = this._roadMap.getJunctions();
		Iterator<Junction> itj = MapaJunctions.iterator();
		while(itj.hasNext()) {
			itj.next().advance(_time);
		}
	}
	
	private void advanceRoads() {
		// TODO Auto-generated method stub
		List<Road> MapaRoads= new ArrayList<Road>();
		MapaRoads= this._roadMap.getRoads();
		Iterator<Road> itr = MapaRoads.iterator();
		while(itr.hasNext()) {
			itr.next().advance(_time);
		}
	}
	
	public JSONObject report() {
		JSONObject jreport = new JSONObject();
		jreport.put("time", this._time);
		jreport.put("state", this._roadMap.report());
		return jreport;
	}
    //...

	@Override
	public void addObserver(TrafficSimObserver o) {
		_observers.add(o);
	}


	@Override
	public void removeObserver(TrafficSimObserver o) {
		// TODO Auto-generated method stub
		_observers.remove(o);
	}


	public int get_time() {
		return _time;
	}


	public RoadMap get_roadMap() {
		return _roadMap;
	}
}
